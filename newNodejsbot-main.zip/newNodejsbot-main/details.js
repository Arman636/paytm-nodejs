module.exports = {
    token: '5166228737:AAGNGYOOX6chNLMA9KMFvnR-zZq_GYq470E',
    admins: [5035811352],
    curr:'INR'
}

